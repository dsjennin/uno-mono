## example app for play 2.3 using anormcypher 0.5

[http://play-2-3-anormcypher-0-5.herokuapp.com/](http://play-2-3-anormcypher-0-5.herokuapp.com/)

### quick overview

* add anormcypher to build.sbt
* add Global.scala with server configuration
* enjoy anormcypher in your controllers
